## identify clades based on certain key non-synoymous mutations

import os, cova

dr = '/home/farhan/projects/covid19/results/local'
fin = os.path.join( dr, 'genome_vars.tsv')
fout = os.path.join( dr, 'genome_clades.csv')
fclades = '/home/farhan/github/cova/cova/data/clade_muts.csv'

clade_mut = { i[0]:i[1] for i in cova._utils.readcsv(fclades)}

data = cova._utils.readcsv(fl=fin,sep='\t',header=True)[1]

genome_clade = []
for row in data:
	genome = row[0]
	sharedv = row[4].split(',')
	for k,v in clade_mut.items():
		if v in sharedv:
			genome_clade.append([genome,k])
			break

cova._utils.writecsv(fl=fout, data=genome_clade)