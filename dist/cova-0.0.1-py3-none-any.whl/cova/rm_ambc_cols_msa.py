import os, sys
from Bio import AlignIO, Seq

dr = sys.argv[1]
	
fin = os.path.join( dr, 'genome_aln_unq.fna')
fout = os.path.join( dr, 'genome_aln_wo_ambc.fna')

def msawoambc(fin,fout,chars='ACGT-'):
	# biopython alignment object
	msa = AlignIO.read(handle=fin, format='fasta')
	# no. of columns
	ncols = msa.get_alignment_length()
	# list of sequences from the non-gapped columns
	ngcs = [  msa[:,x] for x in range(ncols) if not any( i not in chars for i in msa[:,x]) ]
	# list of modified sequences for sequence records
	modseqs = [ ''.join(i) for i in zip(*ngcs) ]
	for x,i in enumerate(msa):
		i.seq = Seq.Seq(modseqs[x])
	AlignIO.write(msa,fout,'fasta')

msawoambc(fin, fout)