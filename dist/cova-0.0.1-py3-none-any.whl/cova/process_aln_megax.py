import os, sys
from Bio import AlignIO

dr = sys.argv[1]
	
fin = os.path.join( dr, sys.argv[2])
fout = fin.replace('.fna','.fas')

aln = AlignIO.read(fin,'fasta')

for i in aln:
	i.description = ''

AlignIO.write(aln,fout,'fasta')