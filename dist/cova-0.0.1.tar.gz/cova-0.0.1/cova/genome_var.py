import os, re
from cova import _utils
def genome_var(fin,fout):
	"""
	Write a table of genomes and their shared and unique annotated point mutations.

	Arguments:
	- fin - full path to the file of annotated variants table
	- fout - full path to output file
	"""
	## checks
	if not os.path.exists(fin):
		raise FileNotFoundError("input file %s must be present."%fin)
	# if output is alaready present
	action = True
	if os.path.exists(fout):
		response=input('''output file %s already exists. 
Do you want to proceed and rewrite it? [y/n]\n'''%fout)
		if response == 'n':
			action = False
		elif response == 'y':
			action = True
		else:
			raise ValueError('''Inappropriate input! Please respond with [y] to
proceed and overwrite OR with [n] to terminate this command''')

	if not action:
		print("okay! Exiting.")
		return

	# annotation table
	head_van, van = _utils.readcsv( fl=fin, sep='\t', header=True)
	# subset of non-synonymous variants
	nsmv = [ i for i in van if len(set(re.split('\d+',i[-2]))) > 1]
	# list of all such variants
	allvs = [ '_'.join([ row[1], row[-2]]) for row in nsmv]
	# dict of genomes and variants
	genome_vrs = {}
	for x, row in enumerate(nsmv):
		v = allvs[x]
		genomes = row[-1].split(',')
		for genome in genomes:
			if genome not in genome_vrs.keys():
				genome_vrs[genome] = [v]
			else:
				genome_vrs[genome].append(v)

	# for every genome, get number and values of all, shared and unique variants
	genome_vls = {}

	for genome,var in genome_vrs.items():
		# no. of variants
		nvs = len(var)
		
		# set of variants in other genomes
		other_vs = set( i for k,v in genome_vrs.items() if k != genome for i in v)
		# shared variants
		shared_vs = set(var) & other_vs
		nsv = len(shared_vs)
		# unique varuants
		unq_vs = set(var) - other_vs
		nuv = len(unq_vs)
		# make an entry in the dict
		genome_vls[genome] = [ nvs, nsv, nuv, shared_vs, unq_vs]

	# process output table
	out = [ [k] + v[:3] + [ ','.join(v[3]), ','.join(v[4])] for k,v in genome_vls.items() ]
	# write to file
	_utils.writecsv(fl=fout, data=out, sep='\t',\
		header=['genome','#variants','#shared', '#unique', 'shared', 'unique'])