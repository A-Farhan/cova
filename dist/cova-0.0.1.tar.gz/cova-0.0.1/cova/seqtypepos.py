### using diversity scan of the genome, identify positions to do for sequence typing

## require
import pandas as pd
from Bio import AlignIO
from cova._utils import list_ep

## arguments
th = 0.001

## paths
fdv = '/home/farhan/projects/covid19/results/global/amb1/slide_divs.csv'
fvr = '/home/farhan/projects/covid19/results/global/amb1/prot_point_mutations_ann.tsv'
fout = '/home/farhan/github/cova/barcodes_cova.txt'

dv = pd.read_csv(fdv,header=None)
vr = pd.read_csv(fvr,sep='\t')

# add a column for no. of genomes
vr['N'] = [ i.count(',') for i in vr.genomes]
# and one to identify mutation type
vr['Type'] = [ 'N' if j[0] != j[-1] else 'S' for j in vr.aa_change ]

# no. of diversity windows
nw = dv.shape[0]

hdr = []

for i in range(1,nw-1):
  dp,dc,dn = dv.iloc[i-1:i+2,2]
  
  if dc >= th:
  	
  	if i == 1:
  		iniw = 0

  	if dp < th:
  		iniw = i

  if dc >= th:

  	if dn < th:
  		finw = i
  	elif i == nw-2:
  		finw = nw
  	else:
  		continue

  	entry = [iniw,finw]
  	hdr.append(entry)

# convert to data frame
hdr = pd.DataFrame(hdr)
# exclude the first and the last region
hdr = hdr.iloc[ 1:-1, ]
# no. of such regions
nr = hdr.shape[0]

stpos = []
for i in range(nr):
	sub = dv.iloc[ hdr.iat[i,0] : hdr.iat[i,1], :]
	# div values
	ds = sub.iloc[:,2]
	# max div
	mxd = max(ds)
	# only keep windows with max div
	sub = sub[ ds == mxd]
	# indices of windows with max div
	ixs = sub.index.to_list()
	# regions, as represented by indices of their windows
	regs = list_ep(ixs)
	# longest region
	lreg = sorted( regs, key = lambda x: x[1]-x[0], reverse=True)[0]
	# its end points on the genome
	ends = ( sub.at[ lreg[0], 0], sub.at[ lreg[1], 1])
	print(ends)
	subv = vr[ (vr.position >= ends[0]) & (vr.position <= ends[1]) & (vr.Type == 'N')]
	pos = subv.position[ subv.N == subv.N.max()].to_list()[0]	
	stpos.append(pos)

with open(fout,'w') as flob:
	for p in stpos:
		flob.write(str(p)+'\n')












