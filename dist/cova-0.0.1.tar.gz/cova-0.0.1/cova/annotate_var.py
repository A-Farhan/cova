import os, re, subprocess, matplotlib, seaborn, ete3
from cova import _utils, FEATURETABLE, GENOME, PROTNAMES
from time import time
from Bio import SeqIO, AlignIO
from Bio.Align import MultipleSeqAlignment
from Bio.Data.CodonTable import unambiguous_dna_by_id as codon_table

def annotate_var(fin,fout,ft=FEATURETABLE,genome=GENOME,codon_table=codon_table[1],\
	rfs_type=-1,rfs_pos=13468,rfs_prot='YP_009725307.1'):
	"""
	Annotate point mutations located within protein regions. Identify amino acid changes
	corresponding to nucleotide changes. The output table is saved to a file and not
	returned. It is a nested list of lists, where each entry is a list of the following
	7 elements.
	- 0 : protein id
	- 1 : protein name, as present in the reference feature table
	- 2 : 1-indexed genomic position
	- 3 : nucleotide variant
	- 4	: reference codon
	- 5 : variant codon
	- 6 : amino acid change
			A string with 3 components:
			- reference aa
			- 1-indexed aa position 
			- variant aa

	Arguments:
	- fin 			- full path to input file of point mutations table
	- fout 			- full path to output file of annotated mutations
	- ft 			- NCBI reference feature table 
	- genome 		- NCBI reference assembly genome
	- codon_table 		- Biopython codon table 	[ Standard]
	
	Additional arguments:
	To account for ribosomal frameshifting present in Coronavirus
	- rfs_type 		- type 				[ -1 ]
	- rfs_pos 		- 1-indexed genomic position 	[ 13468 ]
	- rfs_prot 		- protein id 			[ 'YP_009725307.1' ]
	"""
	# list of stop codons
	stopc = codon_table.stop_codons
	# point mutations variant table
	head, vartab = _utils.readcsv(fl=fin,sep='\t',header=True) 
	# list of genomes
	genomes = head[2:]
	# subset feature table to columns of interest
	prot_ftrs = { i[10]:[ int(i[7]), int(i[8]), i[13]] for i in ft if i[0] in ['CDS','mat_peptide'] \
				and 'polyprotein' not in i[13]}

	## dict of proteins variants and genomes
	var_genomes = {}
	# for every row in the variant table
	for row in vartab:
		# 1-indexed variant position
		pos = int(row[0])
		# reference base
		rb = row[1]
		# find the affected protein(s)
		prots = [ k for k,v in prot_ftrs.items() if v[0] <= pos <= v[1] ]
		if len(prots) == 0:
			continue

		# set of tuples( prot, pos, ref, var nuc)
		pprn = set( ( prot, pos, rb, i) for i in row[2:] if i != rb for prot in prots)
		# dict with above tuples as keys and list of genome ids as their values
		entry = { k:[ genomes[x] for x,i in enumerate(row[2:]) if i == k[3] ] for k in pprn}
		var_genomes.update(entry)

	# list of all variant tuples
	vtups = list(var_genomes.keys())
	# dict of protein and their variants
	prot_vrs = _utils.split_data(data=vtups, ix=0, cixs=[0,1,2,3])

	# initialize output table
	out = []
	# for every protein and its list of variants
	for prot, vrs in prot_vrs.items():
		# list of relevant features of the protein
		ftrs = prot_ftrs[prot]
		# 0-indexed ends
		b = ftrs[0]-1
		e = ftrs[1]

		# CDS sequence
		if prot == rfs_prot:
			cds_seq = genome[b:rfs_pos] + genome[rfs_pos+rfs_type:e]
		else:
			cds_seq = genome[b:e]
		
		# corresponding list of codons
		try:
			codonls = _utils.n2c(cds_seq)
		except _utils.LenSeqError:
			print("\tsequence of {} is not a multiple of 3 ( invalid CDS).".format(ftrs[2].upper()))
			continue
		# remove the terminal stop codon, if present
		if codonls[-1] in stopc:
			codonls = codonls[:-1]

		# for every variant position
		for nvp in vrs:
			# 0-index of the genome position
			genome_x = nvp[1]-1
			# corresponding index in the CDS
			if prot == rfs_prot:
				if genome_x < (rfs_pos-1):
					cds_x = genome_x - b
				else:
					cds_x = genome_x - b - rfs_type
			else:
					cds_x = genome_x - b
			# list of amino acid variant(s)
			avs = _utils.nv2av(p=cds_x, v=nvp[3], seq=codonls, codon_table=codon_table)
			# make an entry in the output table
			entry = [ [ prot, ftrs[2] ] + nvp[1:] + i + [','.join(var_genomes[tuple(nvp)])]\
				for i in avs]
			out.extend(entry)
	
	head = ['protein_id', 'name', 'position', 'ref_base', 'variant_base',\
			'old_codon','new_codon','aa_change', 'genomes']
	_utils.writecsv(fl=fout,data=out, header=head,sep='\t')
