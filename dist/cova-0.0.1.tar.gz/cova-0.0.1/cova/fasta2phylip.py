from Bio import SeqIO

dr = sys.argv[1]

fin = os.path.join( dr, sys.argv[2])
fout = os.path.join( dr, sys.argv[3])

recs = SeqIO.parse(fin,'fasta')
SeqIO.write(recs,fout,'phylip')