import os, pandas, re

fin = '/home/farhan/projects/covid19/results/global/prot_point_mutations_ann.tsv'
## checks
if not os.path.exists(fin):
	raise FileNotFoundError("input file %s must be present."%fin)

# annotation table
van = pandas.read_csv(fin,sep='\t')
# only non-synonymous variants
nsmv = van[ van.type == 'N']
# no. of such variants
N = len(nsmv)
# join protein's name and amino acid change
allvs = nsmv['name'] + '_' + nsmv['aa_change']
# dict of genomes and variants
genome_vrs = {}

for x in range(N):
	v = allvs.iat[x]
	genomes = nsmv['genomes'].iat[x].split(',')
	for genome in genomes:
		if genome not in genome_vrs.keys():
			genome_vrs[genome] = [v]
		else:
			genome_vrs[genome].append(v)

# for every genome, get number and values of all, shared and unique variants
genome_vls = {}

for genome,var in genome_vrs.items():
	# no. of variants
	nvs = len(var)
	
	# set of variants in other genomes
	other_vs = set( i for k,v in genome_vrs.items() if k != genome for i in v)
	# shared variants
	shared_vs = set(var) & other_vs
	nsv = len(shared_vs)
	# unique varuants
	unq_vs = set(var) - other_vs
	nuv = len(unq_vs)
	# make an entry in the dict
	genome_vls[genome] = [ nvs, nsv, nuv, ','.join(shared_vs), ','.join(unq_vs)]
